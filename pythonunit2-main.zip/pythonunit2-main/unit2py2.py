
coordinates = (10, 20, 30) 

print(coordinates[1]) # Output: 20 

days = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
