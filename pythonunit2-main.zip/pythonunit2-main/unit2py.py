# Creating a list 
fruits = ["apple", "banana", "cherry", "apple"] 

# Accessing items (Indexing starts at 0) 
print(fruits[0])  # Output: apple 

# Changing an item 
fruits[1] = "blueberry" 

# Adding an item 
fruits.append("orange") 

# Removing an item 
fruits.remove("cherry") 

print(fruits) 
# Output: ['apple', 'blueberry', 'apple', 'orange']