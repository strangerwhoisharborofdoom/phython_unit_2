#using map() = reminder of numbers / even number
#program to find reminder of number using map() even number

numbers = [1,4,9,16,25]
even = list(filter(lambda x:x%2 == 0, numbers))

print("Original List:", numbers)
print("Even Number:",even)