book={
    "Title" : "Alice in Wonder Land",
    "Author" : "Charles Lutwidge Dodgson",
    "Price" : "14USD",
    }
print(book["Title"])