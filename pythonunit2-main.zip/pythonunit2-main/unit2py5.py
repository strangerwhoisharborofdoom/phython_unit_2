#using map() = dquare of numbers

#program to find square of number using map()

numbers = [1,2,3,4,5]
squares = list(map(lambda x:x**2, numbers))

print("Original List:", numbers)
print("Squares:",squares)