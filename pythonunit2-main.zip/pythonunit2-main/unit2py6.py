#using map() = root of numbers
#program to find square root of number using map()
import math

numbers = [1,4,9,16,25]
squares = list(map(lambda x:math.sqrt(x), numbers))

print("Original List:", numbers)
print("Squares:",squares)