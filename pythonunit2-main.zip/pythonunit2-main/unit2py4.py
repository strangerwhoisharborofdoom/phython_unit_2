# Creating a dictionary
 car = {  "brand": "Ford",  "model": "Mustang",  "year": 1964 } 

 # Accessing a value using its key 
 print(car["model"]) # Output: Mustang 
 
 # Changing a value 
 car["year"] = 2022 
 
 # Adding a new key-value pair 
 car["color"] = "red" 
 
 # Removing a pair 
 car.pop("model") 
 
 print(car)